const RealTimecom= ()=>{
    return <h2>This is real time chat of AI</h2>
    
}
export default RealTimecom;