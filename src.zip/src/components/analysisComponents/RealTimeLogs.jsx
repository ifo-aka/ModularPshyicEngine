import LiveLogChart from "../DashBoardWighets/LiveLogChart";

const RealTimeLogs = () => {
    return <div className="RealTimeLogs box">
        <LiveLogChart />
        </div>
}
export default RealTimeLogs;
