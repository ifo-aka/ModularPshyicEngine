import "./dashBoardStyles.css";
import RadarDataChart from "../DashBoardWighets/RadarDataChat";

const Data = () => {
    return <div className="data box">
                <RadarDataChart />
                </div>
}
export default Data;
// Compare this snippet from TheDashBoarder/src/components/analysisComponents/SystemOverview.jsx: