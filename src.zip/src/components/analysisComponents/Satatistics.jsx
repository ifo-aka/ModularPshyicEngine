import LineGraph from "../DashBoardWighets/LineGraph";


const Statistics= ()=>{
    return    <div className="statistics box">
                  <LineGraph />
                </div>
}
export default Statistics;