import WeightTrack from "../DashBoardWighets/WeightTrack";

const SystemOverview= ()=>{
   return <div className="systemOverview box"><WeightTrack /></div>
}
export default SystemOverview;