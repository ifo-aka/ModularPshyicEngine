import SuggestionChart from "../DashBoardWighets/SuggestionChart";
const Suggestions = ()=>{
    return  <div className="suggestions box" >
        <SuggestionChart good={90} bad={60} />
               
                   
                    
                </div>
}
export default Suggestions;